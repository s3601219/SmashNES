using System.Collections.Generic;
using UnityEngine;

public class HitVisDrawer : MonoBehaviour
{
    public static HitVisDrawer Instance { get; private set; }

    [Header("Appearance")]
    public Material lineMaterial;            // leave null to auto-create Sprites/Default
    [Range(0.5f, 10f)] public float lineWidth = 0.03f;
    [Range(8, 64)]     public int circleSegments = 20;

    // Toggle at runtime (bind this to your key or InputAction)
    public bool visible = true;

    // simple pool of renderers; disabled when not used this frame
    readonly List<LineRenderer> pool = new();
    int usedThisFrame = 0;

    void Awake()
    {
        if (Instance && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        if (!lineMaterial)
        {
            var shader = Shader.Find("Sprites/Default");
            lineMaterial = new Material(shader);
        }
    }

    void LateUpdate()
    {
        // disable any unused renderers at the end of the frame
        for (int i = usedThisFrame; i < pool.Count; i++)
            pool[i].gameObject.SetActive(false);

        usedThisFrame = 0;
    }

    LineRenderer GetLR()
    {
        if (usedThisFrame < pool.Count)
        {
            var lr = pool[usedThisFrame];
            lr.gameObject.SetActive(true);
            usedThisFrame++;
            return lr;
        }

        var go = new GameObject($"HitVis_{pool.Count}");
        go.transform.SetParent(transform, false);
        var newLR = go.AddComponent<LineRenderer>();
        newLR.material = lineMaterial;
        newLR.widthMultiplier = lineWidth;
        newLR.positionCount = 0;
        newLR.loop = true;
        newLR.useWorldSpace = true;
        newLR.numCapVertices = 2;
        newLR.sortingOrder = 32767; // on top
        pool.Add(newLR);
        usedThisFrame++;
        return newLR;
    }

    public void ToggleVisible() => visible = !visible;

    public void DrawCircle(Vector2 center, float radius, Color color, int? segOverride = null)
    {
        if (!visible) return;
        int segs = Mathf.Clamp(segOverride ?? circleSegments, 8, 256);

        var lr = GetLR();
        lr.startColor = lr.endColor = color;
        lr.positionCount = segs;

        float step = Mathf.PI * 2f / segs;
        for (int i = 0; i < segs; i++)
        {
            float a = i * step;
            lr.SetPosition(i, center + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * radius);
        }
    }

    public void DrawBox(Vector2 center, Vector2 size, Color color)
    {
        if (!visible) return;
        var lr = GetLR();
        lr.startColor = lr.endColor = color;
        lr.positionCount = 4;

        Vector2 h = size * 0.5f;
        lr.SetPosition(0, new Vector3(center.x - h.x, center.y - h.y));
        lr.SetPosition(1, new Vector3(center.x - h.x, center.y + h.y));
        lr.SetPosition(2, new Vector3(center.x + h.x, center.y + h.y));
        lr.SetPosition(3, new Vector3(center.x + h.x, center.y - h.y));
    }
}
