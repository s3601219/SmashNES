using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(PlatformFighterController))]
[RequireComponent(typeof(PlatformFighterActor))]
[RequireComponent(typeof(FighterInput))]
public class AttackController : MonoBehaviour
{
    [Header("Data")]
    public AttackSet moves;
    public LayerMask hurtboxMask;

    [Header("Debug / Visuals")]
    [Tooltip("Draw bubbles/boxes at runtime using Debug.DrawLine (Game view).")]
    public bool showHitVis = true;

    [Tooltip("Key to toggle hitbox/hitbubble visibility at runtime.")]
    public KeyCode toggleHitVisKey = KeyCode.H;

    [Tooltip("Approximate circle with this many line segments.")]
    [Range(8, 64)] public int circleSegments = 20;

    [Header("Hit Shape")]
    [Tooltip("If ON, use circles (hitbubbles). If OFF, use original boxes.")]
    public bool useHitBubbles = true;

    [Tooltip("When converting from a window 'size' to a bubble, use max(size.x,size.y)/2 as radius. If OFF, uses avg(size)/2.")]
    public bool bubbleRadiusFromMaxAxis = true;

    [Header("Aerial Behavior")]
    public bool aerialEndsOnLanding = true;   // your existing flag

    PlatformFighterController ctrl;
    PlatformFighterActor actor;
    FighterInput input;
    Animator anim;
    Rigidbody2D rb;
    bool busy;

    int facing => ctrl.FacingRight ? 1 : -1;

    void Awake()
    {
        ctrl  = GetComponent<PlatformFighterController>();
        actor = GetComponent<PlatformFighterActor>();
        input = GetComponent<FighterInput>();
        anim  = GetComponentInChildren<Animator>();
        rb    = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // runtime toggle for visibility
        if (Input.GetKeyDown(toggleHitVisKey))
            showHitVis = !showHitVis;

        if (busy) return;

        if (moves == null)
        {
            if (input.AttackPressed || input.SmashPressed || input.SpecialPressed)
                Debug.LogWarning($"{name}: AttackController has no AttackSet assigned.");
            return;
        }

        // Smash button: smashes on ground, aerials in air
        if (input.SmashPressed)
        {
            var clip = SelectSmash();
            if (clip != null) StartCoroutine(DoAttack(clip));
            return;
        }

        // Specials
        if (input.SpecialPressed)
        {
            var clip = SelectSpecial();
            if (clip != null) StartCoroutine(DoAttack(clip));
            return;
        }

        // Normals
        if (input.AttackPressed)
        {
            var clip = SelectNormal();
            if (clip != null) StartCoroutine(DoAttack(clip));
        }
    }

    AttackClip SelectNormal()
    {
        float x = input.Move.x, y = input.Move.y;

        if (!ctrl.Grounded)
        {
            if (y > input.dirThreshold)  return moves.upAir;
            if (y < -input.dirThreshold) return moves.dair;

            if (Mathf.Abs(x) > input.dirThreshold)
            {
                bool forward = (x > 0f && ctrl.FacingRight) || (x < 0f && !ctrl.FacingRight);
                return forward ? moves.nair : moves.bair; // if you add 'fair', use it here
            }
            return moves.nair; // neutral air
        }
        else
        {
            if (y > input.dirThreshold)  return moves.upTilt;
            if (y < -input.dirThreshold) return moves.downTilt;
            return moves.tilt; // neutral/side tilt
        }
    }

    AttackClip SelectSmash()
    {
        float x = input.Move.x, y = input.Move.y;

        if (!ctrl.Grounded)
        {
            // In air, Smash button = aerials
            if (y > input.dirThreshold)  return moves.upAir;
            if (y < -input.dirThreshold) return moves.dair;

            if (Mathf.Abs(x) > input.dirThreshold)
            {
                bool back = (x > 0f && !ctrl.FacingRight) || (x < 0f && ctrl.FacingRight);
                return back ? moves.bair : moves.nair;
            }
            return moves.nair;
        }
        else
        {
            // On ground, Smash button = smashes
            if (y > input.dirThreshold)  return moves.upSmash;
            if (y < -input.dirThreshold) return moves.dsmash;
            return moves.fsmash;
        }
    }

    AttackClip SelectSpecial()
    {
        float x = input.Move.x, y = input.Move.y;

        // Same selection on ground/air for now
        if (y > input.dirThreshold)  return moves.upSpecial;
        if (y < -input.dirThreshold) return moves.downSpecial;
        if (Mathf.Abs(x) > input.dirThreshold) return moves.special;
        return moves.special;
    }

    IEnumerator DoAttack(AttackClip clip)
    {
        if (clip == null) yield break;

        busy = true;

        if (!string.IsNullOrEmpty(clip.animatorTrigger) && anim)
            anim.SetTrigger(clip.animatorTrigger);

        // Startup frames
        for (int i = 0; i < clip.startupFrames; i++)
            yield return new WaitForFixedUpdate();

        bool startedInAir      = !ctrl.Grounded;
        bool landedDuringAlive = false;

        // Compute longest active window so we know how many frames to iterate
        int maxActive = 0;
        foreach (var w in clip.windows)
            maxActive = Mathf.Max(maxActive, w.startFrame + w.activeFrames - 1);

        var hitThisAttack = new HashSet<PlatformFighterActor>(); // one-hit-per-target per attack

        // ACTIVE frames
        for (int f = 1; f <= maxActive; f++)
        {
            // Landing ends aerial active (if desired)
            if (startedInAir && ctrl.Grounded && aerialEndsOnLanding)
            {
                landedDuringAlive = true;
                break;
            }

            foreach (var w in clip.windows)
            {
                if (f < w.startFrame || f >= w.startFrame + w.activeFrames) continue;

                // Center is current body pos + window offset, with X flipped by facing
                Vector2 center = (Vector2)(rb ? rb.position : (Vector2)transform.position)
                               + new Vector2(w.offset.x * facing, w.offset.y);

                if (useHitBubbles)
                {
                    // Bubble radius from window size (interpreting size as diameter box)
                    float r = bubbleRadiusFromMaxAxis
                        ? Mathf.Max(w.size.x, w.size.y) * 0.5f
                        : (w.size.x + w.size.y) * 0.25f; // average * 0.5

                    // Detect hits
                    var hits = Physics2D.OverlapCircleAll(center, r, hurtboxMask);
                    foreach (var h in hits)
                    {
                        var t = h.GetComponentInParent<PlatformFighterActor>();
                        if (t == null || t == actor) continue;
                        if (hitThisAttack.Contains(t)) continue;

                        t.AddDamage(w.damage);
                        Vector2 kb = new Vector2(w.kbDir.x * facing, w.kbDir.y);
                        t.ApplyKnockback(kb, w.baseKB, w.growth);
                        hitThisAttack.Add(t);
                    }

                    // Visualize bubble at runtime
                    if (showHitVis) DrawCircle(center, r, Color.red, circleSegments);
                }
                else
                {
                    // Original BOX behavior
                    var hits = Physics2D.OverlapBoxAll(center, w.size, 0f, hurtboxMask);
                    foreach (var h in hits)
                    {
                        var t = h.GetComponentInParent<PlatformFighterActor>();
                        if (t == null || t == actor) continue;
                        if (hitThisAttack.Contains(t)) continue;

                        t.AddDamage(w.damage);
                        Vector2 kb = new Vector2(w.kbDir.x * facing, w.kbDir.y);
                        t.ApplyKnockback(kb, w.baseKB, w.growth);
                        hitThisAttack.Add(t);
                    }

                    if (showHitVis)
                    {
                        Vector2 half = w.size * 0.5f;
                        Vector3 a = new(center.x - half.x, center.y - half.y);
                        Vector3 b = new(center.x - half.x, center.y + half.y);
                        Vector3 c = new(center.x + half.x, center.y + half.y);
                        Vector3 d = new(center.x + half.x, center.y - half.y);
                        Debug.DrawLine(a, b, Color.red, Time.fixedDeltaTime);
                        Debug.DrawLine(b, c, Color.red, Time.fixedDeltaTime);
                        Debug.DrawLine(c, d, Color.red, Time.fixedDeltaTime);
                        Debug.DrawLine(d, a, Color.red, Time.fixedDeltaTime);
                    }
                }
            }

            yield return new WaitForFixedUpdate();
        }

        // Endlag or landing lag
        if (landedDuringAlive && clip.landingLag > 0)
        {
            for (int i = 0; i < clip.landingLag; i++)
                yield return new WaitForFixedUpdate();
        }
        else
        {
            for (int i = 0; i < clip.endlagFrames; i++)
                yield return new WaitForFixedUpdate();
        }

        busy = false;
    }

    // ---------- Helpers ----------

    void DrawCircle(Vector2 center, float radius, Color color, int segments)
    {
        if (segments < 3) segments = 3;
        float step = Mathf.PI * 2f / segments;
        Vector3 prev = center + new Vector2(Mathf.Cos(0f), Mathf.Sin(0f)) * radius;

        for (int i = 1; i <= segments; i++)
        {
            float ang = step * i;
            Vector3 next = center + new Vector2(Mathf.Cos(ang), Mathf.Sin(ang)) * radius;
            Debug.DrawLine(prev, next, color, Time.fixedDeltaTime);
            prev = next;
        }
    }
}
