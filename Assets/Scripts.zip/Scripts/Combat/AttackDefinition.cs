using UnityEngine;

[CreateAssetMenu(menuName = "SSB/Attack Definition")]
public class AttackDefinition : ScriptableObject
{
    public float startupFrames = 20;   // frames before hitbox appears
    public float activeFrames = 20;    // active duration
    public float endlagFrames = 20f;    // after active
    public float damage = 8f;
    public float baseKB = 3.0f;
    public float growth = 0.06f;
    public Vector2 knockbackDir = new Vector2(1, 0.5f); // forward-up
    public Vector2 hitboxOffset = new Vector2(0.2f, 0.1f);
    public Vector2 hitboxSize = new Vector2(0.25f, 0.25f);
}
