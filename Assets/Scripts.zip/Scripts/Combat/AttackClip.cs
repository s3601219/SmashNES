using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "SSB/Attack Clip")]
public class AttackClip : ScriptableObject
{
    [Header("Frame Timings")]
    public int startupFrames = 3;       // frames before first hitbox
    public int endlagFrames = 10;       // frames after last window

    public int landingLag = 0;

    [Header("Optional animation trigger")]
    public string animatorTrigger;      // e.g., "Jab", "UTilt", "Nair"

    [Header("Windows (can be multiple for multi-hit/sweetspot)")]
    public List<HitboxWindow> windows = new();   // processed in order
}

[Serializable]
public class HitboxWindow
{
    public int startFrame = 1;          // relative to after startup
    public int activeFrames = 2;        // duration this window is active



    [Header("Hitbox shape")]
    public Vector2 offset = new(0.2f, 0.1f); // local units (PPU-aware)
    public Vector2 size = new(0.30f, 0.30f);

    [Header("On-hit")]
    public float damage = 8f;
    public float baseKB = 3.0f;
    public float growth = 0.06f;
    public Vector2 kbDir = new(1, 0.4f);     // will flip X on facing left
}
