using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class PercentUI : MonoBehaviour
{
    public PlatformFighterActor target;
    public TextMeshProUGUI label;
    void Update() => label.text = Mathf.RoundToInt(target != null ? target.percent : 0f) + "%";
}
